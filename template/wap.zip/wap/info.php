<?php
return array(
	'name'    => 'wap版模板', //模板名称
	'remark'  => '模板名称.', // 模板简单介绍
	'img'     => 'logo.png', // 后台显示模板缩列图 相对于模板目录路径
	'type'    => 'mobile',   //模板类型，pc为PC端模板，mobile为手机端模板
	'version' => 'v1', // 模板版本
	'author'  => 'huahua', // 作者
);